import os
import fitz

from PyQt5 import QtWidgets
from PyQt5 import QtGui
from PyQt5 import QtCore

from GUIs.Ui_Main_menu import Ui_MainWindow
from GUIs.Ui_Add_book import Ui_Add_book

from Reader import Reader

import Controller


class REBoOKS(QtWidgets.QMainWindow):
	def __init__(self, login, password):
		super(REBoOKS, self).__init__()
		self.ui = Ui_MainWindow()
		self.ui.setupUi(self)
		self.login = login
		self.db = Controller.UserDB(self.login, password)
		self.init_books()

		self.ui.button_add.clicked.connect(self.add_book)
		self.ui.button_read.clicked.connect(self.read_book)
		self.ui.button_export.clicked.connect(self.export_book)
		self.ui.button_remove.clicked.connect(self.remove_book)
		self.ui.list_books.itemDoubleClicked.connect(self.read_book)

	def init_books(self):
		self.ui.list_books.clear()
		books = self.db.get_all_books()
		if books:
			for book in books:
				if book[1]:
					book = book[0] + ":\n" + book[1]
				else:
					book = book[0]
				self.ui.list_books.addItem(book)

	def add_book(self):
		existing_books = self.db.get_all_names()

		self.form_add_book = WindowAddBook(existing_books)
		self.form_add_book.setWindowModality(QtCore.Qt.ApplicationModal)
		self.form_add_book.show()

		if self.form_add_book.exec_() != QtWidgets.QDialog.Accepted:
			return

		try:
			book = fitz.open(self.form_add_book.file_name)
		except:
			print("Не удалось открыть книгу")
			return

		content = ""
		for page in range(book.pageCount):
			content += book.loadPage(page).getText().replace('\t', ' ').replace('\n', ' ')



		self.db.add_book(self.form_add_book.name_book, self.form_add_book.description, content) #!!!

		self.init_books()

	def read_book(self):
		current_book = self.ui.list_books.item(self.ui.list_books.currentRow())
		if not current_book:
			return

		current_book = current_book.text().split(":")[0]
		book = self.db.get_book(current_book)
		self.reader = Reader(book[0], book[1])

	def export_book(self):		
		current_book = self.ui.list_books.item(self.ui.list_books.currentRow())
		if not current_book:
			return

		current_book = current_book.text().split(":")[0]
		book = self.db.get_book(current_book)[1] # book = [title, content], we getting 'content'

		fileName = QtWidgets.QFileDialog.getSaveFileName(self, "Экспортировать книгу в .txt", None, "*.txt")[0]
		if fileName:
			with open(fileName, "w", encoding="utf-8") as fileName:
				fileName.write(book)

	def remove_book(self):
		current_book = self.ui.list_books.item(self.ui.list_books.currentRow())
		if not current_book:
			return

		current_book = current_book.text().split(":")[0]
		self.db.remove_book(current_book)
		self.init_books()


class WindowAddBook(QtWidgets.QDialog):
	def __init__(self, existing_books):
		super(WindowAddBook, self).__init__()
		self.ui = Ui_Add_book()
		self.ui.setupUi(self)

		self.file_name = ""
		self.existing_books = existing_books

		self.ui.button_open_book.clicked.connect(self.open_book)

		self.ui.button_save.clicked.connect(self.save_book)

	def open_book(self):
		self.file_name = QtWidgets.QFileDialog.getOpenFileName(self, "Открыть книгу .pdf", None, "*.pdf")[0]

		self.ui.lineEdit_path_to_book.setText(self.file_name)

	def save_book(self):
		self.name_book = self.ui.lineEdit_name_book.text()
		if self.name_book in self.existing_books:
			self.ui.lineEdit_name_book.setStyleSheet("border: 1px solid red; background-color: white")
			self.ui.label_name_book_warning.setText("Имя занято!")
			return

		if self.file_name != "" and self.name_book != "":
			if ":" in self.name_book:
				self.ui.lineEdit_name_book.setStyleSheet("border: 1px solid red; background-color: white")
				self.ui.label_name_book_warning.setText("Не допустимый символ ':'")
				return
			self.description = self.ui.textEdit_description.toPlainText()
			self.accept()
		else:
			if self.name_book == "":
				self.ui.lineEdit_name_book.setStyleSheet("border: 1px solid red; background-color: white")
				self.ui.label_name_book_warning.setText("Заполните поле!")
			if self.file_name == "":
				self.ui.lineEdit_path_to_book.setStyleSheet("border: 1px solid red")
				self.ui.label_path_to_book_warning.setText("Выберете книгу!")
