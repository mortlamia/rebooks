import os
import sqlite3
import hashlib

from Encryption import Cipher


class ManageDB:
	def __init__(self):
		if not os.path.exists("Data/"):
			os.mkdir("Data/")
			os.mkdir("Data/Users/")
		self.db = sqlite3.connect("Data/Users.db")
		self.cursor = self.db.cursor()

		try:
			self.cursor.execute("SELECT * FROM Users")
		except sqlite3.OperationalError as er:
			self.cursor.execute("CREATE TABLE Users (Name text, Password text)")


	def get_all_users(self):
		request = self.cursor.execute("SELECT Name FROM Users").fetchall()
		names = [i[0] for i in request]
		return names

	def is_verified_user(self, login, password):
		password = hashlib.sha512(password.encode()).hexdigest()
		self.cursor.execute("SELECT * FROM Users WHERE Name=?", [(login)])
		request = self.cursor.fetchone()
		if request:
			if password == request[1]:
				return True
			else:
				return False
		else:
			return False

	def create_user(self, login, password):
		password = hashlib.sha512(password.encode()).hexdigest()
		self.cursor.execute("INSERT INTO Users VALUES (?,?)", (login, password))
		self.db.commit()


class UserDB:
	def __init__(self, login, password):
		self.cipher = Cipher(password)
		self.db = sqlite3.connect(f"Data/Users/{login}/{login}.db")
		self.cursor = self.db.cursor()

		try:
			self.cursor.execute("SELECT * FROM Books")
		except sqlite3.OperationalError as er:
			self.cursor.execute("""CREATE TABLE Books 
				(Title text, Description text, Content text, Salt text, Nonce text, Tag text)""")

	def add_book(self, title, description, content):
		result = [title, description]
		result += self.cipher.encrypt(content)
		result = tuple(result)

		self.cursor.execute("INSERT INTO Books VALUES (?,?,?,?,?,?)", result)
		self.db.commit()


	def get_book(self, title):
		self.cursor.execute("SELECT * FROM Books WHERE Title=?", [(title)])
		request = self.cursor.fetchone()
		book = self.cipher.decrypt(list(request[2:6]))
		return [request[0], book]

	def get_all_books(self):
		request = self.cursor.execute("SELECT Title, Description FROM Books").fetchall()
		books = [i for i in request]
		return books

	def get_all_names(self):
		request = self.cursor.execute("SELECT Title FROM Books").fetchall()
		books = [i[0] for i in request]
		return books		

	def remove_book(self, title):
		self.cursor.execute("DELETE FROM Books WHERE Title=?", [(title)])
		self.db.commit()

