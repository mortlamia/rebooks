import os

from PyQt5 import QtWidgets
from PyQt5 import QtGui
from PyQt5 import QtCore

from GUIs.Ui_Login import Ui_Login
import Controller

from MainWindow import REBoOKS


class Entrance(QtWidgets.QWidget):
	def __init__(self):
		super(Entrance, self).__init__()
		self.ui = Ui_Login()
		self.ui.setupUi(self)
		self.bd = Controller.ManageDB()

		self.ui.button_login.clicked.connect(self.login)
		self.ui.button_register.clicked.connect(self.register)

		self.ui.lineEdit_login.returnPressed.connect(self.login)
		self.ui.lineEdit_password.returnPressed.connect(self.login)

		self.show()

	def login(self):
		if self.ui.lineEdit_password.text() == "" or self.ui.lineEdit_login.text() == "":
			self.create_error()
			return

		login = self.ui.lineEdit_login.text()
		password = self.ui.lineEdit_password.text()
		if self.bd.is_verified_user(login, password):
			self.main_menu = REBoOKS(login, password)
			self.main_menu.show()
			self.close()
		else:
			self.ui.label_error.setText("Wrong login or password!")
			self.ui.lineEdit_password.setStyleSheet("border: 1px solid red; background-color: white")
			self.ui.lineEdit_login.setStyleSheet("border: 1px solid red; background-color: white")

	def register(self):
		if self.ui.lineEdit_password.text() == "" or self.ui.lineEdit_login.text() == "":
			self.create_error()
			return

		login = self.ui.lineEdit_login.text()
		password = self.ui.lineEdit_password.text()
		if login in self.bd.get_all_users():
			self.ui.label_error.setText("User exists")
			self.ui.lineEdit_login.setStyleSheet("border: 1px solid red; background-color: white")
			return

		if self.register_user(login, password):
			self.main_menu = REBoOKS(login, password)
			self.main_menu.show()
			self.close()


	def create_error(self):
		if self.ui.lineEdit_login.text() == "":
			self.ui.label_error.setText("Enter Login!")
			self.ui.lineEdit_login.setStyleSheet("border: 1px solid red; background-color: white")
			return

		if self.ui.lineEdit_password.text() == "":
			self.ui.label_error.setText("Enter Password!")
			self.ui.lineEdit_login.setStyleSheet("border: 1px solid black; background-color: white")
			self.ui.lineEdit_password.setStyleSheet("border: 1px solid red; background-color: white")
			return

	def register_user(self, login, password):
		self.bd.create_user(login, password)
		try:
			path = "Data/Users/" + str(login)
			os.mkdir(path)
		except OSError:
			self.ui.label_error.setText("Directory exists! Or not rights!")
			self.ui.lineEdit_login.setStyleSheet("border: 1px solid red; background-color: white")
			return False

		return True
