import sys

from PyQt5 import QtWidgets

from Entrance import Entrance

if __name__ == "__main__":
	app = QtWidgets.QApplication([])
	application = Entrance()

	sys.exit(app.exec())
