from PyQt5 import QtWidgets
from PyQt5 import QtGui
from PyQt5 import QtCore

from GUIs.Ui_Reader import Ui_Reader


class Reader(QtWidgets.QMainWindow):

	resized = QtCore.pyqtSignal()
	dict_sizes = {
		11: [10, 24],
		12: [11, 25],
		13: [12, 29],
		14: [13, 29],
		15: [14, 31],
		16: [15, 34]
	}

	def __init__(self, title, text):
		super(Reader, self).__init__()
		self.ui = Ui_Reader()
		self.ui.setupUi(self)

		_translate = QtCore.QCoreApplication.translate
		self.setWindowTitle(_translate("Add_book", title))

		self.ui.book_text.resize(650, 540)

		self.text = text

		self.font_size = 14
		self.change_size_font()

		self.progress = 1

		self.adjust_text_reader()
		
		self.ui.slider_progress.valueChanged.connect(self.__update_pages)
		self.resized.connect(self.adjust_text_reader)
		self.ui.enlarge_text.triggered.connect(self.enlarge_text)
		self.ui.reduce_text.triggered.connect(self.reduce_text)
		self.ui.export_book.triggered.connect(self.export_book)

		self.show()


	def adjust_text_reader(self):
		size_reader = [self.ui.book_text.size().width(), self.ui.book_text.size().height()]
		size_symbol = self.dict_sizes[self.font_size]

		self.pages = self.splitting_text(self.text, size_symbol, size_reader)

		self.count_pages = len(self.pages)
		self.ui.slider_progress.setMaximum(self.count_pages)

		self.__update_pages(self.progress)


	def splitting_text(self, text, size_symbol, size_reader):
		width_symbol, height_symbol = size_symbol
		width_reader, height_reader = size_reader 
		const_count_columns = width_reader // width_symbol + 1 # (погрешность в виде пробела в начале)
		const_count_rows = height_reader // height_symbol

		count_columns = const_count_columns
		count_rows = const_count_rows

		pages = {}

		list_text = text.split()

		text_on_page = ""
		index = 1

		for word in list_text:
			len_word = len(word) + 1  # пробел перед словом (example: " казалось", " прийдёт")
			if count_columns - len_word < 0:
				count_columns = const_count_columns
				if count_rows - 1 < 0:
					count_rows = const_count_rows
					pages[index] = text_on_page
					text_on_page = word
					index += 1
					continue
				else:
					count_rows -= 1
			
			count_columns -= len_word
			text_on_page += " " + word

		pages[index] = text_on_page

		return pages

	def resizeEvent(self, event):
		self.resized.emit()
		return super(Reader, self).resizeEvent(event)

	def __update_pages(self, value):
		self.progress = self.ui.slider_progress.value()
		self.ui.label_progress.setText(f"{value}/{self.count_pages}")
		self.ui.book_text.setText(self.pages[value])

	def enlarge_text(self):
		if self.font_size < 16:
			self.font_size += 1
			self.change_size_font()
			self.adjust_text_reader()

	def reduce_text(self):
		if self.font_size > 11:
			self.font_size -= 1
			self.change_size_font()
			self.adjust_text_reader()
			
	def change_size_font(self):
		font = QtGui.QFont()
		font.setFamily("Consolas")
		font.setPointSize(self.font_size)
		self.ui.book_text.setFont(font)

	def export_book(self):
		fileName = QtWidgets.QFileDialog.getSaveFileName(self, "Экспортировать книгу в .txt", None, "*.txt")[0]
		if fileName:
			with open(fileName, "w", encoding="utf-8") as fileName:
				fileName.write(self.text)

